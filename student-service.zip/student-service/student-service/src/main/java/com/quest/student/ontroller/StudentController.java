package com.quest.student.ontroller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.quest.student.entity.Student;
import com.quest.student.services.StudentService;

@RestController
@RequestMapping("/api/student")
public class StudentController {

	@Autowired

	private StudentService studentService;
	
    //ResponseEntity:->as a response type here we can provide a complete response to this class like status
	@PostMapping("/addstudent")
	public ResponseEntity<Student>saveStudent(@RequestBody Student student){
		return new ResponseEntity<Student>(studentService.saveStudent(student), HttpStatus.CREATED);


	}

	//build get all Students rest api
	@GetMapping("/getallstudents")
	public List<Student> getAllStudents(){
		return studentService.getAllStudents();



	}

     //@PathVariable:->whatever variable have you passed in path variable that should be matched 
	//build get students by id restapi
	@GetMapping("{id}")
	public ResponseEntity<Student> getStudentById(@PathVariable("id")  long StdId){
		return new ResponseEntity<Student>(studentService.getStudentById(StdId),HttpStatus.OK);



	}

	//build update student rest api
	@PutMapping("{id}")
	public ResponseEntity<Student> updateStudent(@PathVariable("id") long stdId, @RequestBody Student student){
		return  new ResponseEntity<Student>(studentService.updateStudent(student, stdId),HttpStatus.OK);

	}



	//build deletestudent restapi

	@DeleteMapping("{id}")
	public ResponseEntity<Map<String, String>> deleteStudent(@PathVariable("id") long stdId){

		Map<String, String> response = new HashMap<>();

		studentService.deleteStudent(stdId);

		response.put("msg", "id deleted successfully");
		return   ResponseEntity.ok(response);


	}




	//		@DeleteMapping("{id}")
	//		public Map<String,String> deleteStudent(@PathVariable("id") long stdId){
	//			
	//			studentService.deleteStudent(stdId);
	//			Map<String,String> result=new HashMap<String,String>();
	//			return new ResponseEntity<String>("Book deleted successfully!!", HttpStatus.OK);
	//			
	//			
	//		}
	//		





}
