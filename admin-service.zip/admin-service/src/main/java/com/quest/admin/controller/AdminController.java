package com.quest.admin.controller;

import java.util.List;

import org.aspectj.weaver.patterns.ThisOrTargetAnnotationPointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.quest.admin.entity.Book;
import com.quest.admin.entity.Student;


@RestController
@RequestMapping("/api/admin")
public class AdminController {

	@Autowired
	private RestTemplate restTemplate;

	//Admin will add the student
	//@RequestBody:-the Spring framework binds the incoming HTTP request body to that parameter.
	@PostMapping("/addAdminStudent")
	public ResponseEntity<Student> saveStudent(@RequestBody Student student){
		return restTemplate.postForEntity("http://localhost:8088/api/student/addstudent/", student, Student.class);
	}


	//we will fetch all the records of students
	@GetMapping("/allstd")
	public List<Student> getAllStudents(){
		List<Student> students=restTemplate.getForObject("http://localhost:8088/api/student/getallstudents/", List.class);
		return students;

	}

	//data will updated by id
	//path variable:-It is used to extract the values from the URI. It is most suitable for the RESTful web service, 
	//where the URL contains a path variable. We can define multiple @PathVariable in a method.
	@PutMapping("/{id}")
	public void updateStudent(@PathVariable("id") long stdId, @RequestBody Student student){
		restTemplate.put("http://localhost:8088/api/student/"+stdId, student );
		System.out.println("Data updated successfully");
	}

	//data will be deleted by id
	@DeleteMapping("{id}")
	public void deleteStudent(@PathVariable("id") long stdId){
		restTemplate.delete("http://localhost:8088/api/student/"+stdId);

	}


	//Book will be added by the Admin API'S
	@PostMapping("/adminAddBook")
	public ResponseEntity<Book>addbook(@RequestBody Book book){
		return restTemplate.postForEntity("http://localhost:8082/api/book/addbook/", book, Book.class);

	}


	//keep all the record of book
	@GetMapping("/allBookRecord")
	public List<Book> getAllBooks(){
		List<Book> books=restTemplate.getForObject("http://localhost:8082/api/book/getallbooks/", List.class);
		return books;

	}

	//Admin will delete the book
	@DeleteMapping("/bk/{id}")
	public void deleteBook(@PathVariable("id") long bookId){
		restTemplate.delete("http://localhost:8082/api/book/"+bookId);
	}



	//Filter book by subject
	@GetMapping("/searchBySubject/{subject}")
	public List<Book> searchBookByName(@PathVariable("subject")  String subject){
		//return restTemplate.getForObject("http://localhost:8082/api/book/searchBySubject"+subject, Book.class);
		List<Book> books=restTemplate.getForObject("http://localhost:8082/api/book/searchBySubject/"+subject, List.class);
		return  books; 
	}




}
