package com.quest.library.services;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.quest.library.entity.Book;
import com.quest.library.exception.ResourceNotFoundException;
import com.quest.library.repository.LibraryRepository;


@Service
public class LibraryServiceImpl implements LibraryService {

	@Autowired
	public LibraryRepository libraryRepository;

	@Override
	public Book addbook(Book book) {
		// TODO Auto-generated method stub
		return libraryRepository.save(book);
	}

	@Override
	public List<Book> getAllBooks() {

		return libraryRepository.findAll();
	}

	@Override
	public Book getBookById(Long bookId) {
		// TODO Auto-generated method stub 
		Optional<Book> book = libraryRepository.findById(bookId);
		// 1st way
		//	if(book.isPresent()) {
		//		
		//		return book.get();
		//	}else {
		//		
		//		throw new ResourceNotFoundException("Book", "bookId", bookId);
		//	}

		//2nd way
		return libraryRepository.findById(bookId).orElseThrow(()->new ResourceNotFoundException("Book", "BookID", bookId));


	}


	//	@Override
	//	public Book getBookBySubject(String subject) {
	//		 Optional<Book> book = libraryRepository.findAll(subject);
	//		return null;
	//	}

	@Override
	public Book updateBook(Book book, long bookId) {
		// we need to check wheather book with given id is exist or not


		Book existingBook  = libraryRepository.findById(bookId).orElseThrow(
				()->new ResourceNotFoundException("Book", "BookId", bookId));

		existingBook.setSubject(book.getSubject());
		existingBook.setAuthorName(book.getAuthorName());
		existingBook.setPrice(book.getPrice());
		//save existing book to db
		libraryRepository.save(existingBook);

		return existingBook;
	}

	@Override
	public void deleteBook(long bookId) {
		//check wheather a book exist in db or not
		libraryRepository.findById(bookId).orElseThrow(
				()->new ResourceNotFoundException("Book", "BookId", bookId));

		libraryRepository.deleteById(bookId);

	}

	@Override
	public List<Book> searchBook() {

		List<Book>  list=libraryRepository.findAll();

		Comparator<Book> idComp = Comparator.comparing(Book::getBookId);
		Comparator<Book> subComp = Comparator.comparing(Book::getSubject);

		Comparator<Book> mulComp =idComp.thenComparing(subComp);

		Collections.sort(list,mulComp);

		return list;



	}

	@Override
	public List<Book> searchBookByName(String subject) {

		List<Book>  list=libraryRepository.findAll();

		List<Book> sub = list.stream().filter(ss->ss.getSubject().equals(subject)).collect(Collectors.toList());
		return sub;

	}





}
